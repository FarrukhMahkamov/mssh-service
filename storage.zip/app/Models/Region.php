<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Region extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'slug',
        'state_id',
    ];

    public function state() {
        return $this->belongsTo(State::class);
    }

    public function region() {
        return $this->hasMany(Region::class);
    }

    public function user() {
        return $this->hasMany(User::class);
    }

}
